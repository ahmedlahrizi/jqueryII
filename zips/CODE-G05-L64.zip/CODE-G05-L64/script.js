$(document).ready(function () {
    const oof = 4;
});
console.log(oof);
